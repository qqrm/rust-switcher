# rust-switcher
like dotSwitcher but not abandoned
